"""Regression tests for genuine runtime contamination and missing-package failures."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bootstrap036", ROOT / "scripts/bootstrap_python036.py")
bootstrap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bootstrap)


@pytest.mark.parametrize("line", ["numpy>=2\n", "numpy==2.5.4\n", "numpy==2.5.4 --hash=sha256:invalid\n"])
def test_partial_locks_rejected(tmp_path, line):
    path = tmp_path / "requirements.lock"
    path.write_text(line)
    with pytest.raises(ValueError, match="hash lock"):
        bootstrap.read_hash_lock(path)


def test_duplicate_locked_names_rejected(tmp_path):
    path = tmp_path / "requirements.lock"
    hashed = " --hash=sha256:" + "a" * 64 + "\n"
    path.write_text("some_pkg==1" + hashed + "some-pkg==1" + hashed)
    with pytest.raises(ValueError, match="Duplicate"):
        bootstrap.read_hash_lock(path)


def test_existing_destination_is_not_repaired(tmp_path):
    with pytest.raises(ValueError, match="must not exist"):
        bootstrap.preflight(ROOT, tmp_path, "3.12")


def test_missing_local_package_rejected(tmp_path):
    with pytest.raises(ValueError, match="Local editable package"):
        bootstrap.preflight(tmp_path, tmp_path / "new-env", "3.12")


def probe(tmp_path):
    prefix = tmp_path / "env"
    return {"version": "3.12.15", "prefix": str(prefix), "base_prefix": str(tmp_path / "base"), "user_site_enabled": False,
            "venv_config": "include-system-site-packages = false\n",
            "distributions": [{"name": "constraint-research", "version": "0.1.0", "metadata_path": str(prefix / "local.dist-info")}],
            "module_origins": {name: str((ROOT / "packages/constraint-research/src/constraint_research/__init__.py") if name == "constraint_research" else (prefix / name / "__init__.py")) for name in bootstrap.MODULES}}


def test_seed_metadata_contamination_rejected(tmp_path):
    data = probe(tmp_path)
    data["distributions"] += [{"name": "pip", "version": version, "metadata_path": str(tmp_path / "env" / ("pip-" + version))} for version in ("25.0", "26.2.1")]
    with pytest.raises(ValueError, match="Duplicate distribution"):
        bootstrap.assert_probe(data, {"pip": "26.2.1"}, ROOT, "3.12.15")


def test_empty_metadata_directory_rejected(tmp_path):
    data = probe(tmp_path)
    data["distributions"].append({"name": None, "version": None, "metadata_path": str(tmp_path / "empty.egg-info")})
    with pytest.raises(ValueError, match="Malformed distribution"):
        bootstrap.assert_probe(data, {}, ROOT, "3.12.15")


def test_external_import_is_rejected(tmp_path):
    data = probe(tmp_path)
    data["module_origins"]["numpy"] = "/different-workspace/site-packages/numpy/__init__.py"
    with pytest.raises(ValueError, match="imported-module origin"):
        bootstrap.assert_probe(data, {}, ROOT, "3.12.15")


def test_unexpected_installed_version_is_rejected(tmp_path):
    data = probe(tmp_path)
    data["distributions"][0]["version"] = "9.9.9"
    with pytest.raises(ValueError, match="Installed versions"):
        bootstrap.assert_probe(data, {}, ROOT, "3.12.15")


def test_system_site_packages_is_rejected(tmp_path):
    data = probe(tmp_path)
    data["venv_config"] = "include-system-site-packages = true\n"
    with pytest.raises(ValueError, match="System site-packages"):
        bootstrap.assert_probe(data, {}, ROOT, "3.12.15")
