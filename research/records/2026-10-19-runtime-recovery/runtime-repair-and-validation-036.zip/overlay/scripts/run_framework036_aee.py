#!/usr/bin/env python3
"""Assess feature-036 governance claims; scientific checks are separate."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
FEATURE = ROOT / 'specs/036-runtime-reproducibility'
ADAPTER = ROOT / '.specify/extensions/aee/scripts/python/run_aee.py'
PHASES = ('after_specify', 'after_plan', 'after_tasks', 'after_implement')


def main():
    if not shutil.which('aee'):
        raise SystemExit('Required AEE executable is unavailable')
    dest = FEATURE / 'aee'
    dest.mkdir(exist_ok=True)
    phases = sys.argv[1:] or list(PHASES)
    expected = {c['id'] for c in json.loads((FEATURE/'aee-claims.json').read_text())['claims']}
    for phase in phases:
        if phase not in PHASES:
            raise SystemExit(f'Unknown AEE phase: {phase}')
        subprocess.run([sys.executable, str(ADAPTER), '--project-root', str(ROOT),
                        'assess', '--input', str(FEATURE/'aee-claims.json'),
                        '--phase', phase, '--threshold', '0.70', '--no-ledger'], check=True, cwd=ROOT)
        latest = max((ROOT/'.specify/extensions/aee/assessments').glob(f'aee-{phase}-*.json'),
                     key=lambda p: p.stat().st_mtime_ns)
        assessment = json.loads(latest.read_text())
        if assessment['outcome'] not in ('pass', 'warn'):
            raise SystemExit(f'AEE closure blocked: {assessment["outcome"]}')
        assert {c['id'] for c in assessment['claims']} == expected
        subprocess.run([sys.executable, str(ADAPTER), '--project-root', str(ROOT),
                        'gate', '--input', str(latest)], check=True, cwd=ROOT)
        history = dest/'history'
        history.mkdir(exist_ok=True)
        key = __import__('hashlib').sha256(latest.read_bytes()).hexdigest()
        shutil.copyfile(latest, history/(phase+'-'+key+'.json'))
        shutil.copyfile(latest, dest/(phase+'.json'))
        snapshot = {'phase': phase, 'assessment_sha256': key,
                    'scope': 'runtime recovery revision 2; available baseline only',
                    'new_scientific_studies_executed': 0,
                    'specification_sha256': __import__('hashlib').sha256((FEATURE/'spec.md').read_bytes()).hexdigest()}
        (history/(phase+'-'+key+'-inputs.json')).write_text(json.dumps(snapshot, indent=2)+'\n')
    if 'after_implement' in phases:
        subprocess.run([sys.executable, str(ADAPTER), '--project-root', str(ROOT),
                        'challenge', '--input', str(FEATURE/'aee-claims.json'),
                        '--phase', 'after_implement', '--threshold', '0.70'], check=True, cwd=ROOT)
        latest = max((ROOT/'.specify/extensions/aee/challenges').glob('aee-after_implement-*.json'),
                     key=lambda p: p.stat().st_mtime_ns)
        assert not json.loads(latest.read_text()).get('failures')
        shutil.copyfile(latest, dest/'challenge-after_implement.json')
    print('OK: feature 036 governance checkpoints passed; no physical validation inferred.')


if __name__ == '__main__':
    main()
