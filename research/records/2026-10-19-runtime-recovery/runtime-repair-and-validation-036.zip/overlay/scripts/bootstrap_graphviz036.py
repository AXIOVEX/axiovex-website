#!/usr/bin/env python3
"""Install a hash-pinned Graphviz runtime locally on Ubuntu 24.04 x86_64.

No packages are installed into the host. System shared libraries remain explicit
host dependencies; inspect the retained ldd and dpkg receipts for their identity.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import struct
import subprocess
import sys
import time
from urllib.parse import urlparse


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def save(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def run(argv: list[str], log: Path, *, env: dict | None = None,
        timeout: int = 120) -> dict:
    start = time.monotonic()
    started = utc_now()
    with log.open("w") as stream:
        result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT,
                                check=False, env=env, timeout=timeout)
    receipt = {"argv": argv, "started_utc": started, "finished_utc": utc_now(),
               "elapsed_seconds": round(time.monotonic() - start, 6),
               "exit_code": result.returncode, "log": log.name,
               "log_sha256": digest(log), "log_bytes": log.stat().st_size}
    save(log.with_suffix(".json"), receipt)
    if result.returncode != 0:
        raise RuntimeError(f"Command failed ({result.returncode}); inspect {log}")
    return receipt


def validate_lock(lock: dict) -> None:
    if lock.get("schema") != "graphviz-local-runtime-lock-v1":
        raise ValueError("Unsupported Graphviz lock schema")
    packages = lock.get("packages", [])
    if not packages or len(packages) > 64:
        raise ValueError("Missing or oversized package lock")
    names = set()
    for entry in packages:
        name = entry.get("name", "")
        url = urlparse(entry.get("url", ""))
        if (not re.fullmatch(r"[a-z0-9][a-z0-9+.-]*", name) or name in names
                or url.scheme != "https" or url.netloc != "archive.ubuntu.com"
                or not url.path.startswith("/ubuntu/pool/")
                or not url.path.endswith(".deb") or url.query or url.fragment
                or ".." in url.path.split("/")
                or entry.get("architecture") != "amd64"
                or not re.fullmatch(r"[0-9a-f]{64}", entry.get("sha256", ""))
                or not isinstance(entry.get("bytes"), int)
                or not 0 < entry["bytes"] <= 64 * 1024 * 1024):
            raise ValueError(f"Invalid package lock entry: {name!r}")
        names.add(name)
    if "graphviz" not in names:
        raise ValueError("The lock does not include Graphviz")


def bootstrap(args: argparse.Namespace) -> None:
    lock_path = args.lock.resolve(strict=True)
    lock = json.loads(lock_path.read_text())
    validate_lock(lock)
    operating_system = {}
    for line in Path("/etc/os-release").read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            operating_system[key] = value.strip('"')
    expected = lock["platform"]
    if (operating_system.get("ID") != expected["os_id"]
            or operating_system.get("VERSION_ID") != expected["version_id"]
            or platform.machine() != expected["machine"]):
        raise ValueError("This lock supports Ubuntu 24.04 on x86_64 only")
    for command in ["curl", "dpkg-deb", "dpkg-query", "ldd"]:
        if shutil.which(command) is None:
            raise RuntimeError(f"Required host tool is missing: {command}")
    destination = args.destination.absolute()
    evidence = args.evidence.absolute()
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"Refusing existing Graphviz destination: {destination}")
    if evidence.exists() or evidence.is_symlink():
        raise FileExistsError(f"Refusing existing evidence destination: {evidence}")
    evidence.mkdir(parents=True)
    destination.mkdir(parents=True)
    started = utc_now()
    try:
        cache = destination / "packages"
        native = destination / "root"
        cache.mkdir()
        native.mkdir()
        shutil.copy2(lock_path, evidence / "graphviz-lock.json")
        shutil.copy2(Path("/etc/os-release"), evidence / "os-release.txt")
        shutil.copy2(Path(__file__), evidence / "bootstrap_graphviz036.py")
        run(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Status}\n"],
            evidence / "host-packages-before.log")

        def download(entry: dict) -> dict:
            name = entry["name"]
            package = cache / f"{name}.deb"
            receipt = run([
                "curl", "--fail", "--location", "--silent", "--show-error",
                "--proto", "=https", "--retry", "2", "--connect-timeout", "20",
                "--max-time", "120", "--output", str(package), entry["url"],
            ], evidence / f"download-{name}.log", timeout=400)
            size, sha = package.stat().st_size, digest(package)
            if size != entry["bytes"] or sha != entry["sha256"]:
                raise ValueError(f"Downloaded package size/hash mismatch: {name}")
            metadata = subprocess.run(
                ["dpkg-deb", "--show", "--showformat=${Package}\t${Version}\t${Architecture}",
                 str(package)], check=True, capture_output=True, text=True).stdout
            if metadata != f"{name}\t{entry['version']}\t{entry['architecture']}":
                raise ValueError(f"Downloaded package metadata mismatch: {name}")
            return {"name": name, "version": entry["version"],
                    "url": entry["url"], "bytes": size, "sha256": sha,
                    "metadata": metadata, "status": "pass", "download": receipt}

        with ThreadPoolExecutor(max_workers=4) as pool:
            downloaded = list(pool.map(download, lock["packages"]))
        save(evidence / "package-verification.json", {"packages": downloaded})
        for entry in lock["packages"]:
            run(["dpkg-deb", "--extract", str(cache / f"{entry['name']}.deb"),
                 str(native)], evidence / f"extract-{entry['name']}.log")

        library = native / "usr/lib/x86_64-linux-gnu"
        plugins = library / "graphviz"
        dot = native / "usr/bin/dot"
        if not dot.exists() or not plugins.is_dir():
            raise RuntimeError("Expected Graphviz binary/plugin directory is absent")
        wrapper_dir = destination / "bin"
        wrapper_dir.mkdir()
        wrapper = wrapper_dir / "dot"
        wrapper.write_text(
            '#!/bin/sh\nset -eu\n'
            'TASK_GRAPHVIZ_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)\n'
            'export LD_LIBRARY_PATH="$TASK_GRAPHVIZ_ROOT/root/usr/lib/x86_64-linux-gnu:$TASK_GRAPHVIZ_ROOT/root/usr/lib"\n'
            'export GVBINDIR="$TASK_GRAPHVIZ_ROOT/root/usr/lib/x86_64-linux-gnu/graphviz"\n'
            'exec "$TASK_GRAPHVIZ_ROOT/root/usr/bin/dot" "$@"\n'
        )
        wrapper.chmod(0o755)
        shutil.copy2(wrapper, evidence / "dot-wrapper.sh")
        env = dict(os.environ)
        env["LD_LIBRARY_PATH"] = str(library) + os.pathsep + str(native / "usr/lib")
        env["GVBINDIR"] = str(plugins)
        targets = sorted({dot.resolve(), *(p.resolve() for p in plugins.glob("*.so*"))})
        dependencies = []
        for index, target in enumerate(targets):
            log = evidence / f"ldd-{index:02d}.log"
            receipt = run(["ldd", str(target)], log, env=env)
            if "not found" in log.read_text():
                raise RuntimeError(f"Missing native dependency; inspect {log}")
            dependencies.append({"target": str(target), "target_sha256": digest(target),
                                 "receipt": receipt})
        save(evidence / "native-dependencies.json", {"targets": dependencies})
        run([str(wrapper), "-c"], evidence / "plugin-configuration.log")
        run([str(wrapper), "-V"], evidence / "dot-version.log")
        graph = evidence / "render-smoke.dot"
        graph.write_text('digraph runtime {\n  graph [bgcolor="white"];\n'
                         '  node [shape=box, style=rounded];\n'
                         '  constraints -> records -> verification;\n}\n')
        dimensions = None
        for format_name in ["png", "svg"]:
            output = evidence / f"render-smoke.{format_name}"
            run([str(wrapper), f"-T{format_name}", str(graph), "-o", str(output)],
                evidence / f"render-{format_name}.log")
            content = output.read_bytes()
            if format_name == "png":
                if content[:8] != b"\x89PNG\r\n\x1a\n" or len(content) < 24:
                    raise RuntimeError("Graphviz did not produce a PNG")
                dimensions = list(struct.unpack(">II", content[16:24]))
                if not all(0 < size < 10000 for size in dimensions):
                    raise RuntimeError("Unexpected rendered PNG dimensions")
            elif b"<svg" not in content or b"</svg>" not in content:
                raise RuntimeError("Graphviz did not produce an SVG")
        run(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Status}\n"],
            evidence / "host-packages-after.log")
        host_unchanged = ((evidence / "host-packages-before.log").read_bytes()
                          == (evidence / "host-packages-after.log").read_bytes())
        if not host_unchanged:
            raise RuntimeError("Host package inventory changed during bootstrap")
        save(evidence / "summary.json", {
            "schema": "graphviz-local-runtime-verification-v1", "status": "pass",
            "run_kind": "fresh recovery verification", "started_utc": started,
            "finished_utc": utc_now(), "destination": str(destination),
            "dot": str(wrapper), "lock_sha256": digest(lock_path),
            "bootstrap_sha256": digest(Path(__file__)),
            "package_count": len(downloaded),
            "package_bytes": sum(p["bytes"] for p in downloaded),
            "reported_dot_version": (evidence / "dot-version.log").read_text().strip(),
            "declared_package_version": next(p["version"] for p in downloaded
                                             if p["name"] == "graphviz"),
            "native_dependency_targets_verified": len(dependencies),
            "render_png_dimensions": dimensions,
            "png_sha256": digest(evidence / "render-smoke.png"),
            "svg_sha256": digest(evidence / "render-smoke.svg"),
            "host_package_inventory_unchanged": host_unchanged,
            "scope": lock["scope"],
            "historical_receipts_recreated": False,
        })
        print(json.dumps({"status": "pass", "dot": str(wrapper),
                          "evidence": str(evidence), "packages": len(downloaded)}))
    except Exception as exc:
        save(evidence / "failure.json", {"status": "fail", "started_utc": started,
                                         "finished_utc": utc_now(),
                                         "type": type(exc).__name__, "error": str(exc)})
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lock", type=Path, default=Path(__file__).resolve().parents[1]
                        / "specs/036-runtime-reproducibility/graphviz-lock.json")
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--evidence", required=True, type=Path)
    bootstrap(parser.parse_args())


if __name__ == "__main__":
    main()
