#!/usr/bin/env python3
"""Install official Spec Kit 1.0.8 from immutable, verified source and hash locks."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
FEATURE = ROOT / "specs/036-runtime-reproducibility"


def verify_archive(path: Path, lock: dict) -> None:
    if path.stat().st_size != lock["size"] or hashlib.sha256(path.read_bytes()).hexdigest() != lock["sha256"]:
        raise ValueError("Spec Kit archive differs from the pinned official artifact")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--archive", type=Path, help="Optional previously downloaded archive; exact hash still required")
    args = parser.parse_args()
    python = args.python.absolute()
    evidence = args.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    work = Path(tempfile.mkdtemp(prefix="spec-kit036-"))
    lock = json.loads((FEATURE / "spec-kit-lock.json").read_text())
    dependencies = FEATURE / "locks/spec-kit312.lock"
    if hashlib.sha256(dependencies.read_bytes()).hexdigest() != lock["dependencies_sha256"]:
        raise SystemExit("Spec Kit dependency lock differs from its contract")
    env = os.environ.copy()
    for key in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV"):
        env.pop(key, None)
    env["PYTHONNOUSERSITE"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    runtime = json.loads(subprocess.check_output([str(python), "-c", "import json,platform,sys;print(json.dumps({'version':platform.python_version(),'executable':sys.executable}))"], text=True, env=env))
    if not runtime["version"].startswith("3.12."):
        raise SystemExit("This governance dependency lock targets Python 3.12")
    receipt = {"schema_version": "1.0", "recovery_revision": 2, "started_utc": datetime.now(timezone.utc).isoformat(), "source": lock, "runtime": runtime, "build_directory": str(work), "commands": [], "status": "running"}
    def save():
        tmp = evidence / "receipt.json.tmp"
        tmp.write_text(json.dumps(receipt, indent=2) + "\n")
        tmp.replace(evidence / "receipt.json")
    def run(label, argv):
        result = subprocess.run(argv, cwd=evidence, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (evidence / (label + ".log")).write_text(result.stdout)
        receipt["commands"].append({"label": label, "argv": argv, "returncode": result.returncode, "log": label + ".log"})
        save()
        if result.returncode:
            raise RuntimeError(label + " failed; retained log in " + str(evidence))
        return result.stdout
    save()
    try:
        archive = args.archive.resolve() if args.archive else work / "spec-kit.tar.gz"
        if not args.archive:
            with urllib.request.urlopen(lock["url"], timeout=60) as response, archive.open("wb") as output:
                total = 0
                while chunk := response.read(1024 * 1024):
                    total += len(chunk)
                    if total > lock["size"]:
                        raise ValueError("Spec Kit download exceeds the pinned artifact size")
                    output.write(chunk)
        verify_archive(archive, lock)
        extracted = work / "source"
        extracted.mkdir()
        with tarfile.open(archive) as source:
            source.extractall(extracted, filter="data")
        package = extracted / ("spec-kit-" + lock["commit"])
        if not (package / "pyproject.toml").is_file():
            raise ValueError("Expected immutable Spec Kit source root is missing")
        run("dependencies", [str(python), "-m", "pip", "install", "--no-input", "--require-hashes", "--only-binary=:all:", "--no-deps", "-r", str(dependencies)])
        run("source-install", [str(python), "-m", "pip", "install", "--no-input", "--no-build-isolation", "--no-deps", str(package)])
        run("pip-check", [str(python), "-m", "pip", "check"])
        details = json.loads(run("installed-source", [str(python), "-c", "import importlib.metadata,json,specify_cli;d=importlib.metadata.distribution('specify-cli');print(json.dumps({'version':d.version,'module':specify_cli.__file__,'direct_url':json.loads(d.read_text('direct_url.json'))}))"]))
        if details["version"] != lock["version"] or details["direct_url"]["url"] != package.as_uri():
            raise ValueError("Installed Spec Kit version or source provenance mismatch")
        run("console-help", [str(python.parent / "specify"), "--help"])
        receipt.update(status="pass", installed=details, finished_utc=datetime.now(timezone.utc).isoformat())
    except Exception as error:
        receipt.update(status="fail", failure=str(error), finished_utc=datetime.now(timezone.utc).isoformat())
        save()
        raise
    save()
    print(json.dumps({"status": receipt["status"], "version": details["version"], "receipt": str(evidence / "receipt.json")}))


if __name__ == "__main__":
    main()
