#!/usr/bin/env python3
"""Recovery revision 2: create and verify an isolated, hash-locked Linux runtime.

This installer does not reconstruct lost scientific artifacts. It refuses to
repair an existing environment in place, preventing inherited metadata from
silently deciding which package version is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
FEATURE = Path("specs/036-runtime-reproducibility")
UV_VERSION = "0.12.23"
VERSIONS = {"3.11": "3.11.17", "3.12": "3.12.15"}
MODULES = ("numpy", "scipy", "sympy", "matplotlib", "pytest", "jsonschema", "PIL", "docx", "constraint_research")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def read_hash_lock(path: Path) -> dict[str, str]:
    """Accept only exact, artifact-hashed requirements, rejecting partial locks."""
    result: dict[str, str] = {}
    for line in path.read_text().replace("\\\n", " ").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s;]+)((?:\s+--hash=sha256:[a-f0-9]{64})+)\s*", line)
        if not match:
            raise ValueError(f"Incomplete or unsupported hash lock entry: {line[:100]}")
        name = normalize(match.group(1))
        if name in result:
            raise ValueError(f"Duplicate locked distribution: {name}")
        result[name] = match.group(2)
    if not result:
        raise ValueError("Empty dependency lock")
    return result


def preflight(repo: Path, destination: Path, minor: str) -> tuple[Path, dict[str, str]]:
    if minor not in VERSIONS:
        raise ValueError(f"Unsupported Python version: {minor}")
    if destination.exists() or destination.is_symlink():
        raise ValueError("Destination must not exist; choose a new empty environment path")
    if not (repo / "packages/constraint-research/pyproject.toml").is_file():
        raise ValueError("Local editable package is missing from the repository")
    lock = repo / FEATURE / "locks" / ("python" + minor.replace(".", "") + ".lock")
    expected = read_hash_lock(lock)
    contract = json.loads((repo / FEATURE / "runtime-lock.json").read_text())
    entry = contract["python"][minor]
    if entry["version"] != VERSIONS[minor] or entry["lock_sha256"] != sha256(lock):
        raise ValueError("Runtime lock hash or interpreter version does not match the contract")
    return lock, expected


def assert_probe(probe: dict, expected: dict[str, str], repo: Path, version: str) -> None:
    if probe["version"] != version:
        raise ValueError("Unexpected Python interpreter version")
    prefix = Path(probe["prefix"]).resolve()
    if prefix == Path(probe["base_prefix"]).resolve() or probe["user_site_enabled"]:
        raise ValueError("Interpreter is not an isolated virtual environment")
    if "include-system-site-packages = false" not in probe["venv_config"].lower():
        raise ValueError("System site-packages isolation is not explicit")
    rows = probe["distributions"]
    if any(not row.get("name") or not row.get("version") for row in rows):
        raise ValueError("Malformed distribution metadata; inspect empty or stale egg-info directories")
    counts = Counter(normalize(row["name"]) for row in rows)
    duplicates = sorted(name for name, count in counts.items() if count != 1)
    if duplicates:
        raise ValueError("Duplicate distribution metadata: " + ", ".join(duplicates))
    actual = {normalize(row["name"]): row["version"] for row in rows}
    if actual != {**expected, "constraint-research": "0.1.0"}:
        raise ValueError("Installed versions differ from the complete dependency lock")
    for row in rows:
        if not Path(row["metadata_path"]).resolve().is_relative_to(prefix):
            raise ValueError("Distribution metadata escaped the environment")
    for name, origin in probe["module_origins"].items():
        root = (repo / "packages/constraint-research/src").resolve() if name == "constraint_research" else prefix
        if not Path(origin).resolve().is_relative_to(root):
            raise ValueError(f"Unexpected imported-module origin: {name}")
    if set(probe["module_origins"]) != set(MODULES):
        raise ValueError("Required import-origin observations are incomplete")


PROBE = r'''
import importlib, importlib.metadata, json, pathlib, platform, site, sys
modules = ["numpy", "scipy", "sympy", "matplotlib", "pytest", "jsonschema", "PIL", "docx", "constraint_research"]
rows = sorted([{"name": d.metadata.get("Name"), "version": d.version, "metadata_path": str(d._path)} for d in importlib.metadata.distributions()], key=lambda row: (row["name"] or "").lower())
print(json.dumps({"version": platform.python_version(), "executable": sys.executable, "prefix": sys.prefix, "base_prefix": sys.base_prefix, "user_site_enabled": site.ENABLE_USER_SITE, "venv_config": (pathlib.Path(sys.prefix)/"pyvenv.cfg").read_text(), "distributions": rows, "module_origins": {name: str(pathlib.Path(importlib.import_module(name).__file__).resolve()) for name in modules}}, indent=2))
'''


def sanitized_environment() -> dict[str, str]:
    env = os.environ.copy()
    for name in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV", "UV_PROJECT_ENVIRONMENT"):
        env.pop(name, None)
    env["PYTHONNOUSERSITE"] = "1"
    return env


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", choices=sorted(VERSIONS), required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=ROOT)
    parser.add_argument("--uv", default="uv")
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    destination = args.destination.absolute()
    lock, expected = preflight(repo, destination, args.python)
    if platform.system() != "Linux" or platform.machine() != "x86_64":
        raise SystemExit("This verified bootstrap targets Linux x86_64 only")
    uv = shutil.which(args.uv)
    if not uv:
        raise SystemExit("Install uv 0.12.23 before running this bootstrap")
    env = sanitized_environment()
    uv_version = subprocess.check_output([uv, "--version"], text=True, env=env).strip()
    if uv_version.split()[1] != UV_VERSION:
        raise SystemExit("Expected uv 0.12.23; refusing a different resolver/runtime catalogue")
    evidence = args.evidence.resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    receipt = {"schema_version": "1.0", "recovery_revision": 2, "started_utc": datetime.now(timezone.utc).isoformat(),
               "repo": str(repo), "destination": str(destination), "uv_version": uv_version,
               "uv_executable_sha256": sha256(Path(uv)), "lock_sha256": sha256(lock), "commands": [], "status": "running"}

    def save() -> None:
        tmp = evidence / "receipt.json.tmp"
        tmp.write_text(json.dumps(receipt, indent=2) + "\n")
        tmp.replace(evidence / "receipt.json")

    def run(label: str, argv: list[str]) -> str:
        row = {"label": label, "argv": argv, "log": label + ".log", "started_utc": datetime.now(timezone.utc).isoformat()}
        receipt["commands"].append(row)
        save()
        completed = subprocess.run(argv, cwd=repo, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (evidence / row["log"]).write_text(completed.stdout)
        row.update(returncode=completed.returncode, finished_utc=datetime.now(timezone.utc).isoformat())
        save()
        if completed.returncode:
            raise RuntimeError(f"{label} failed; inspect {evidence / row['log']}")
        return completed.stdout

    cache = destination.parent / "uv-cache"
    interpreters = destination.parent / "interpreters"
    version = VERSIONS[args.python]
    pybase = interpreters / ("cpython-" + version + "-linux-x86_64-gnu") / "bin" / ("python" + args.python)
    base = [uv, "--no-config", "--cache-dir", str(cache)]
    save()
    try:
        run("interpreter", base + ["python", "install", "--no-bin", "--install-dir", str(interpreters), version])
        run("venv", base + ["venv", "--no-seed", "--python", str(pybase), str(destination)])
        python = str(destination / "bin/python")
        run("dependencies", base + ["pip", "sync", "--python", python, "--require-hashes", str(lock)])
        run("editable", base + ["pip", "install", "--python", python, "--no-build-isolation", "--no-deps", "--editable", str(repo / "packages/constraint-research")])
        run("pip-check", [python, "-m", "pip", "check"])
        probe = json.loads(run("probe", [python, "-c", PROBE]))
        assert_probe(probe, expected, repo, version)
        (evidence / "environment.json").write_text(json.dumps(probe, indent=2) + "\n")
        receipt.update(status="pass", finished_utc=datetime.now(timezone.utc).isoformat(), distribution_count=len(probe["distributions"]))
    except Exception as error:
        receipt.update(status="fail", failure=str(error), finished_utc=datetime.now(timezone.utc).isoformat())
        save()
        raise
    save()
    print(json.dumps({"status": receipt["status"], "python": python, "receipt": str(evidence / "receipt.json")}))


if __name__ == "__main__":
    main()
