#!/usr/bin/env python3
"""Run present-source recovery checks in an isolated copy and retain every log."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET


def stamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--graphviz-bin", type=Path, required=True)
    parser.add_argument("--phase", choices=("experiments", "tests"), required=True)
    args = parser.parse_args()
    root, snapshot, evidence = args.repo.resolve(), args.snapshot.resolve(), args.evidence.resolve()
    if snapshot.exists() or evidence.exists():
        raise SystemExit("Choose new snapshot and evidence directories; prior evidence is never overwritten")
    if snapshot.is_relative_to(root) or not (args.graphviz_bin / "dot").is_file():
        raise SystemExit("Use an external snapshot path and an available Graphviz executable")
    evidence.mkdir(parents=True)
    rows = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if not path.is_file() or any(p in {".git", ".venv", ".lake", "__pycache__", ".pytest_cache", ".publication-checkpoints"} for p in rel.parts):
            continue
        if rel.as_posix().startswith(("specs/036-runtime-reproducibility/evidence/", "results/_tmp/")) or ".egg-info" in rel.as_posix():
            continue
        target = snapshot / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        rows.append({"path": rel.as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    (evidence / "source-snapshot-manifest.json").write_text(json.dumps(rows, indent=2) + "\n")
    env = os.environ.copy()
    for name in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV"):
        env.pop(name, None)
    env.update(PYTHONNOUSERSITE="1", MPLCONFIGDIR=str(evidence / "matplotlib"), PATH=str(args.python.parent) + os.pathsep + str(args.graphviz_bin) + os.pathsep + env.get("PATH", ""))
    probe = subprocess.check_output([str(args.python), "-c", "import constraint_research,json,platform,sys;print(json.dumps({'python':platform.python_version(),'executable':sys.executable,'local_package':constraint_research.__file__}))"], text=True, env=env)
    receipt = {"schema_version": "1.0", "recovery_revision": 2, "started_utc": stamp(), "phase": args.phase, "snapshot": str(snapshot), "runtime": json.loads(probe), "source_file_count": len(rows), "commands": [], "status": "running", "scope": "Available baseline plus current runtime repairs; no missing feature 035 source or results are reconstructed."}
    if args.phase == "experiments":
        commands = [("qd-control", ["scripts/experiment_qd_gate_audit.py"]), ("framework022", ["scripts/verify_framework022.py"]), ("candidate-before", ["scripts/verify_formulator032.py"]), ("run-all", ["scripts/run_all.py"]), ("pair033-replay", ["scripts/experiment_pair033.py", "--check"]), ("pair033-verify", ["scripts/verify_pair033.py"]), ("extra034-verify", ["scripts/verify_extra_dimensions034.py"])]
    else:
        commands = [("pytest", ["-m", "pytest", "--junitxml=" + str(evidence / "pytest.xml")])]
    def save():
        temp = evidence / "validation.json.tmp"
        temp.write_text(json.dumps(receipt, indent=2) + "\n")
        temp.replace(evidence / "validation.json")
    for label, command in commands:
        entry = {"label": label, "argv": [str(args.python), *command], "started_utc": stamp(), "log": label + ".log"}
        receipt["commands"].append(entry)
        save()
        print("START", label, flush=True)
        start = time.monotonic()
        with (evidence / entry["log"]).open("w") as log:
            try:
                result = subprocess.run(entry["argv"], cwd=snapshot, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
                entry["returncode"] = result.returncode
            except subprocess.TimeoutExpired:
                entry["returncode"] = 124
                entry["failure"] = "Engineering timeout after 1200 seconds; retained partial log"
        entry.update(seconds=round(time.monotonic() - start, 3), finished_utc=stamp())
        save()
        print("DONE", label, entry["returncode"], entry["seconds"], flush=True)
    if args.phase == "tests" and (evidence / "pytest.xml").exists():
        tree = ET.parse(evidence / "pytest.xml")
        suites = list(tree.getroot().iter("testsuite"))
        receipt["pytest_counts"] = {key: sum(int(s.attrib.get(key, 0)) for s in suites) for key in ("tests", "failures", "errors", "skipped")}
    changed = []
    for row in rows:
        live = root / row["path"]
        if not live.is_file() or hashlib.sha256(live.read_bytes()).hexdigest() != row["sha256"]:
            changed.append(row["path"])
    receipt.update(status="pass" if all(c["returncode"] == 0 for c in receipt["commands"]) else "fail", finished_utc=stamp(), active_source_changed_during_run=changed)
    save()
    print(json.dumps({"status": receipt["status"], "counts": receipt.get("pytest_counts"), "receipt": str(evidence / "validation.json")}))
    raise SystemExit(0 if receipt["status"] == "pass" else 1)


if __name__ == "__main__":
    main()
