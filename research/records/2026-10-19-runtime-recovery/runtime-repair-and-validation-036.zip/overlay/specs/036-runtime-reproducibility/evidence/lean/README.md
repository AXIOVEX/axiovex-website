# Fresh Lean recovery verification

This directory records a new verification after the previous workspace's runtime and raw execution logs were lost. It does not recreate or backdate the lost receipts. See `summary.json` for the actual UTC timestamps and results.

## Verified result

The root RCPH library and `rcphcheck` executable build successfully with the repository's pinned Lean 4.33.1 toolchain. The build completed 40 jobs in 3.68953 seconds. The `rg` check found no `sorry` or `admit` proof placeholders; its expected no-match exit code is 1. All 22 root Lean source and Lake/toolchain configuration files are byte-identical to the surviving baseline before and after the isolated build.

The archive is the official Linux x86_64 asset from [Lean 4.33.1](https://github.com/leanprover/lean4/releases/tag/v4.33.1), published August 21, 2026. The downloaded 570,405,234 bytes match the official asset digest:

```text
890afd185370f85666025b883914ab4f4b339136f8c96167b69cfb62aecaf235
```

The release's asset metadata is retained as `official-release.json`. `archive-verification.json` binds its hash to the downloaded archive. The versions, commands, durations, exit codes and log hashes have separate receipts. The archive and installed toolchain are deliberately excluded from this small evidence package.

## Recovery method

1. Fetch the official release metadata and the `lean-4.33.1-linux.tar.zst` asset with normal TLS verification.
2. Require the exact version, archive size and SHA-256 shown above before extraction.
3. Extract into a new local toolchain directory with `tar --no-same-owner --zstd -xf lean-4.33.1-linux.tar.zst`. The ownership option permits an unprivileged installation without attempting to recreate the archive owner's identity.
4. Put that toolchain's `bin` directory first on `PATH`, and set `LEAN_SYSROOT` to its root directory. Verify `lean --version` and `lake --version` before running the build. The observed version outputs are retained verbatim.
5. Copy the 22 declared Lean/configuration files into an empty build directory; verify their hashes against both the surviving baseline and the current source tree. Run `lake build` there. Check the root Lean files and `RCPH/` for proof placeholders, then verify the source hashes again.

`rebuild.py` records the exact one-time recovery procedure, including its absolute workspace paths. It intentionally refuses to overwrite an existing toolchain or build directory. The build ran through the approved host execution path; no TLS verification or project validation was disabled. This recovery did not rerun or reconstruct any earlier native-launcher failure.

## Scope

This checks the root build target used by the existing CI configuration. It does not claim to build the separate `formal/fgb1-lean` project. No Lean sources were edited and no new theorems were added. A successful local build does not satisfy current-head CI in the source repository, supply new empirical observations, or close any broader physical reconstruction target.

`manifest.json` lists every retained evidence file other than itself, with byte counts and SHA-256 hashes.
