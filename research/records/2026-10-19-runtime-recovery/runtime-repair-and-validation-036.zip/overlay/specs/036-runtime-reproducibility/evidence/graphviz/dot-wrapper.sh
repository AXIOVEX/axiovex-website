#!/bin/sh
set -eu
TASK_GRAPHVIZ_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export LD_LIBRARY_PATH="$TASK_GRAPHVIZ_ROOT/root/usr/lib/x86_64-linux-gnu:$TASK_GRAPHVIZ_ROOT/root/usr/lib"
export GVBINDIR="$TASK_GRAPHVIZ_ROOT/root/usr/lib/x86_64-linux-gnu/graphviz"
exec "$TASK_GRAPHVIZ_ROOT/root/usr/bin/dot" "$@"
