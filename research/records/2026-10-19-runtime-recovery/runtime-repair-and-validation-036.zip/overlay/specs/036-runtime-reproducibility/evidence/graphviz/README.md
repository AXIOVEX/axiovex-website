# Graphviz recovery and real rendering

This is a fresh October 19, 2026 recovery run. Earlier workspace receipts were not recreated.

## Result

The reproducible installer extracted 11 verified Ubuntu packages into a new local directory, resolved all nine checked binary/plugin dependency targets, generated the local plugin configuration, and rendered both a PNG and an SVG. The PNG is 140 × 251 pixels and was visually inspected: all three labels and both arrows are visible. The complete host package inventory is identical before and after the operation.

The Ubuntu Graphviz package version is `2.42.2-9build1`; the package's binary reports `dot - graphviz version 2.43.0 (0)`. Both values are recorded rather than silently equated. The package archive hashes, not the display string alone, identify the runtime.

The lock was derived from the official Ubuntu Noble `main` and `universe` amd64 indexes over HTTPS. `graphviz-lock.json` records each index URL, size and SHA-256, plus each selected archive's URL, size, SHA-256 and package version. `official-package-stanzas.txt` preserves the exact selected package stanzas. This procedure does not claim a separate verification of the Ubuntu Release-file signature.

## Reproduce

On Ubuntu 24.04 x86_64, from the source repository:

```sh
python3 scripts/bootstrap_graphviz036.py \
  --destination /absolute/path/to/a/new/graphviz-directory \
  --evidence /absolute/path/to/a/new/graphviz-evidence-directory
```

Put the resulting `bin` directory first on `PATH` before running the Python experiment runner. Both destination directories must be new. `curl`, `dpkg-deb`, `dpkg-query` and `ldd` must already be available. The installer preserves failure information and rejects unsupported hosts, malformed locks, archive metadata/hash mismatches, missing native libraries, failed rendering, or an existing destination. It uses ordinary TLS verification and never runs the archives' maintainer scripts or changes the host package database.

The wrapper locates its own installation root and sets the local library and Graphviz plugin paths. Remaining shared libraries come from the declared Ubuntu host: their actual resolution is recorded in the `ldd-*.log` files and their installed package versions in `host-packages-before.log`. This is a locally isolated Graphviz install, not a fully hermetic operating-system image.

## Evidence

`summary.json` gives the actual UTC timestamps, package count, lock and installer hashes, rendering hashes and host-preservation result. Each download, extraction, native-link check and execution has its own return-code and log-hash receipt. Downloaded `.deb` archives and unpacked system libraries are excluded from this small evidence package. `manifest.json` covers every retained evidence file except itself.
