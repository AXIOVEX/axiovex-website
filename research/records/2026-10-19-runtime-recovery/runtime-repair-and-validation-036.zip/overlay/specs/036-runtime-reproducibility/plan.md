# Plan

1. Inventory and hash the surviving source, preserve its frozen inputs, and record the workspace-loss boundary (REQ-RUN-01, 08).
2. Download exact supported Python interpreters, compile complete dependency-hash locks, then create unseeded isolated environments and install the actual local package using a locked build backend (REQ-RUN-02, 03).
3. Add a bootstrap command that verifies versions, package origins and metadata integrity; add regression cases for the real bootstrap failure modes (REQ-RUN-03).
4. Correct Docker's package-copy ordering and CI's matrix-specific constraints. Verify the staged installation boundary (REQ-RUN-04).
5. Restore and execute Graphviz and Lean, preserving archive provenance and command logs (REQ-RUN-05).
6. Run both Python matrices in isolated copies, retain actual outputs, and execute SDD/AEE governance with a pinned Spec Kit installation (REQ-RUN-06, 07).
7. Aggregate fresh evidence, complete AEE implementation assessment and document any remaining current-head CI or missing-artifact boundaries (REQ-RUN-08, 09, 10).

This is an engineering plan recorded before the new repair and validation. It is not a retrospective scientific preregistration.
