# Requirements review

- [x] Scope identifies the user's authorized runtime repair.
- [x] Frozen scientific inputs and historical results are preserved.
- [x] Each supported Python version has an explicit acceptance obligation.
- [x] Actual package origins and metadata integrity are required.
- [x] Missing historical artifacts are distinct from fresh execution.
- [x] Graphviz rendering and Lean compilation require observed execution.
- [x] Docker staged-install validation is distinct from a container build.
- [x] Local validation is distinct from source CI and website publication.
- [x] Every requirement is mapped in the plan and tasks.
