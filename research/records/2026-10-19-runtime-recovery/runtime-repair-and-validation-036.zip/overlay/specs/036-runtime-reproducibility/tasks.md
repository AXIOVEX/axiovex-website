# Tasks

- [x] T01 / REQ-RUN-01,08: inventory and preserve surviving source; document loss boundary.
- [x] T02 / REQ-RUN-09: specify, clarify, plan, checklist and consistency analysis.
- [x] T03 / REQ-RUN-09: run preimplementation AEE checkpoints using restored AEE.
- [x] T04 / REQ-RUN-02,03: create reproducible bootstrap, locks and environment verification.
- [x] T05 / REQ-RUN-04: fix Docker ordering and CI constraints; verify staged installation.
- [x] T06 / REQ-RUN-05: retain Graphviz rendering and Lean build evidence.
- [x] T07 / REQ-RUN-06: complete both fresh Python experiment and test matrices.
- [x] T08 / REQ-RUN-07: execute fresh SDD, AEE and Spec Kit checks.
- [x] T09 / REQ-RUN-08,09,10: aggregate fresh evidence and complete implementation AEE/convergence.
- [ ] T10 / REQ-RUN-10: satisfy source current-head CI after source publication; separate from this local recovery.
