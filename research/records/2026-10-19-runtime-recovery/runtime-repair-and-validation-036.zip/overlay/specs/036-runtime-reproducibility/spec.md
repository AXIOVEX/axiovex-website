# Runtime reproducibility and interruption recovery

## Scope and constitution check

The user authorized repair of missing local packages and rerunning the checks needed before publication. This recovery begins from the surviving source snapshot, not from reconstructed scientific results. The former workspace was lost. Its previous feature 035/036 execution claims are prior-conversation reports until their underlying files can be recovered and verified. An independently recovered feature 035 manifest does not recreate its missing source or results. This feature is an engineering repair; all 14 physical reconstruction targets remain open.

## Requirements

- **REQ-RUN-01**: Preserve frozen requirements, experiment sources, candidate records, proofs and baseline results byte for byte in the active source. Execute mutation-producing checks in isolated copies.
- **REQ-RUN-02**: Provide clean Python 3.11 and 3.12 environments with complete version and artifact-hash locks, an actual editable installation of the local package, and no inherited system packages or seed-pip metadata collisions.
- **REQ-RUN-03**: Record interpreter, distribution and imported-module origins. Refuse an existing environment as a bootstrap destination, unsupported versions, a missing local package, duplicate distributions or a lock mismatch.
- **REQ-RUN-04**: Make the editable local package available before Docker's dependency installation and pin CI dependency resolution to the matching supported lock constraints.
- **REQ-RUN-05**: Restore Graphviz and the pinned Lean toolchain with inspectable provenance and verify their real execution. Do not equate an installer or version string with a successful build or rendering.
- **REQ-RUN-06**: Run the full experiment runner, frozen feature 033 replay, feature 034 verifier and complete test suite on both supported Python versions. Preserve failed attempts and exact commands, return codes, counts and logs.
- **REQ-RUN-07**: Run the available SDD, content/provenance and AEE gates with pinned AEE 1.4.0 and verify the pinned Spec Kit console command.
- **REQ-RUN-08**: Separate fresh retained observations from earlier chat-only reports. Never claim a fresh feature 035 replay without its original source and result artifacts.
- **REQ-RUN-09**: Preserve the full specify, clarify, plan, checklist, tasks, analyze, implement, converge lifecycle and four AEE checkpoints.
- **REQ-RUN-10**: Report local gate status separately from source-repository CI, merge and website publication. A downloadable changeset is not a merge or a current-head CI run.

## Acceptance boundary

The engineering deliverable is a reproducible repair plus fresh retained validation of the available source. Scientific claims remain bounded by their original frozen campaigns. Full source-feature closure remains subject to the repository's current-head CI policy. Missing historical artifacts remain explicit, even if present-source checks pass.
