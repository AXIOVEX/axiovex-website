# Runtime repair and fresh validation — recovery revision 2

This download contains newly authored runtime installers, complete dependency locks, 11 runtime regression cases, engineering specifications, focused execution evidence, and the minimal patch for four existing setup/documentation files. It is an engineering changeset against private source commit 8409f6506bd7c96ab44e44770537e349f1fcfdd1. It does not contain the pre-existing private repository or its detailed source inventory.

Fresh results: Python 3.11.17 and 3.12.15 each passed 222 tests (211 existing cases plus 11 new runtime regressions), with zero failures, errors or skips. All seven experiment/control/replay checks pass on each version. The pinned Lean 4.33.1 build passed 40 jobs; Graphviz rendered real PNG and SVG files; pinned Spec Kit 1.0.8 installed from its verified immutable archive and passed its console check. All 27 baseline governance commands, four runtime-feature AEE checkpoints, the staged missing-package repair and independent engineering review pass.

Use overlay/specs/036-runtime-reproducibility/runtime-setup.md for reproducible setup and overlay/specs/036-runtime-reproducibility/convergence.md for scope and limitations. The machine-readable summary is overlay/specs/036-runtime-reproducibility/validation-summary.json.

To apply this engineering delta, use an isolated checkout of the exact baseline commit. Copy the contents of overlay/ into that checkout, then run:

    git apply --check --unidiff-zero /absolute/path/to/ENGINEERING.patch
    git apply --unidiff-zero /absolute/path/to/ENGINEERING.patch

The patch deliberately uses zero context so unrelated pre-existing private source text is not included. The exact baseline identity is therefore part of the application contract. Source current-head CI remains an integration gate; this public download does not claim a source-repository merge.

The earlier transient workspace was lost. Feature 035 source and raw result files were unavailable during this recovery and have not been reconstructed or freshly replayed. Previous chat reports of 300-test matrices are not evidence for this run. The observed fresh result is 222 tests per Python version against the surviving baseline. No new physical study or empirical validation is claimed; the broader 14 reconstruction targets remain open.

Detailed private-source manifests, snapshot inventories, existing test-case inventories, expanded historical scientific assessments, raw scientific rerun outputs and broad host-package inventories are excluded from this public bundle. They were retained locally for verification. Focused runtime logs, real pytest console totals, aggregate command results and runtime artifact hashes are included. Component receipts may refer to those retained local records; the release manifest enumerates only the files actually included here. Preserved failed runtime attempts are labeled with their subsequent corrections.

No Docker image build was possible in this environment. The actual staged Python-install boundary was tested from an empty environment, including the expected missing-package failure and the repaired package COPY. The container base image and apt layer are not part of the Python artifact lock.
